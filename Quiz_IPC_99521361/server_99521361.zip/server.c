//99521361
//this is code for server
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <stdbool.h>

struct shared_memory {
    char buf [10][256];
    int buffer_index;
    int buffer_print_index;
};

void error (char *msg)
{
    perror (msg);
    exit (1);
}

int main (int argc, char **argv)
{
    struct shared_memory *shared_mem;
    sem_t *mutex_sem, *buffer_count, *spool_signal;
    int shm, log;

    if ((log = open ("/tmp/example.log", O_CREAT | O_WRONLY | O_APPEND | O_SYNC, 0666)) == -1) error ("fopen");
    if ((mutex_sem = sem_open ("/sem-mutex", O_CREAT, 0660, 0)) == SEM_FAILED) error ("sem_open");
    if ((shm = shm_open ("/posix-shared-mem-example", O_RDWR | O_CREAT | O_EXCL, 0660)) == -1) error ("shm_open");
    if (ftruncate (shm, sizeof (struct shared_memory)) == -1) error ("ftruncate"); 
    if ((shared_mem = mmap (NULL, sizeof (struct shared_memory), PROT_READ | PROT_WRITE, MAP_SHARED, shm, 0)) == MAP_FAILED) error ("mmap");
    
    shared_mem -> buffer_index = shared_mem -> buffer_print_index = 0;

    if ((buffer_count = sem_open ("/sem-buffer-count", O_CREAT | O_EXCL, 0660, 10)) == SEM_FAILED) error ("sem_open");
    if ((spool_signal = sem_open ("/sem-spool-signal", O_CREAT | O_EXCL, 0660, 0)) == SEM_FAILED) error ("sem_open");
    if (sem_post (mutex_sem) == -1) error ("sem_post: mutex_sem");

    char mybuf [256];
    while (true) {
        if (sem_wait (spool_signal) == -1) error ("sem_wait: spool_signal_sem");
    
        strcpy (mybuf, shared_mem -> buf[shared_mem -> buffer_print_index]);
        (shared_mem -> buffer_print_index)++;

        if (shared_mem -> buffer_print_index == 10) shared_mem -> buffer_print_index = 0;
        if (sem_post (buffer_count) == -1) error ("sem_post: buffer_count_sem");
        if (write (log, mybuf, strlen (mybuf)) != strlen (mybuf)) error ("write: logfile");
    }
}