//99521361
//this is code for client
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/mman.h>

struct shared_memory {
    char buf [10][256];
    int buffer_index;
    int buffer_print_index;
};

void error (char *msg)
{
    perror (msg);
    exit (1);
}

int main (int argc, char **argv)
{
    struct shared_memory *shared_mem;
    sem_t *mutex_sem, *buffer_count, *spool_signal;
    int shm;
    
    if ((mutex_sem = sem_open ("/sem-mutex", 0, 0, 0)) == SEM_FAILED) error ("sem_open");
    if ((shm = shm_open ("/posix-shared-mem-example", O_RDWR, 0)) == -1) error ("shm_open");
    if ((shared_mem = mmap (NULL, sizeof (struct shared_memory), PROT_READ | PROT_WRITE, MAP_SHARED, shm, 0)) == MAP_FAILED) error ("mmap");
    if ((buffer_count = sem_open ("/sem-buffer-count", 0, 0, 0)) == SEM_FAILED) error ("sem_open");
    if ((spool_signal = sem_open ("/sem-spool-signal", 0, 0, 0)) == SEM_FAILED) error ("sem_open");

    printf ("type a message: ");
    char hold_buffer[200];
    while (fgets (hold_buffer, 198, stdin)) {
        if (hold_buffer[strlen(hold_buffer) - 1] == '\n') hold_buffer[strlen(hold_buffer) - 1] = '\0';

        if (sem_wait (buffer_count) == -1) error ("sem_wait: buffer_count_sem");
        if (sem_wait (mutex_sem) == -1) error ("sem_wait: mutex_sem");

        time_t now = time (NULL);
        char *cp = ctime (&now);
        if (*(cp + strlen(cp) -1) == '\n') *(cp + strlen(cp) -1) = '\0';
        sprintf (shared_mem -> buf[shared_mem -> buffer_index], "%d: %s %s\n", getpid (), cp, hold_buffer);
        (shared_mem -> buffer_index)++;
        if (shared_mem -> buffer_index == 10) shared_mem -> buffer_index = 0;

        if (sem_post (mutex_sem) == -1) error ("sem_post: mutex_sem");
        if (sem_post (spool_signal) == -1) error ("sem_post: (spool_signal_sem");

        printf ("type a message: ");
    }
    if (munmap (shared_mem, sizeof (struct shared_memory)) == -1) error ("munmap");
    exit (0);
}